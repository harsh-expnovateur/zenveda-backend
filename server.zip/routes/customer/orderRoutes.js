// routes/customer/orderRoutes.js
const express = require("express");
const { authenticate } = require("../../middleware/authenticate");
const {
  placeOrder,
  getOrders,
  getOrder,
} = require("../../controllers/customer/orderController");

const router = express.Router();

// All order routes require authentication
router.use(authenticate);

router.post("/", placeOrder);
router.get("/", getOrders);
router.get("/:orderId", getOrder);

module.exports = router;