// routes/upload.js
const express = require("express");
const multer = require("multer");
const path = require("path");

const router = express.Router();

// 🧩 Storage setup
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const isImage = /image/.test(file.mimetype);
    const dest = isImage ? "uploads/images" : "uploads/files";
    cb(null, path.join(__dirname, `../${dest}`));
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB limit
});

// 🧾 POST /api/upload/single
router.post("/single", upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: "No file uploaded" });
  }

  const isImage = /image/.test(req.file.mimetype);
  const relativePath = isImage
    ? `uploads/images/${req.file.filename}`
    : `uploads/files/${req.file.filename}`;

  res.json({
    success: true,
    fileName: req.file.filename,
    relativePath, // path to store in DB
    fullUrl: `${req.protocol}://${req.get("host")}/${relativePath}`, // usable on frontend
  });
});

module.exports = router;
