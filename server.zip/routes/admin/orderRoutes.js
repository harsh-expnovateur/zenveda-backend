// routes/admin/orderRoutes.js
const express = require("express");
const { authenticate, requireAdmin } = require("../../middleware/authenticate");
const {
  getAllOrders,
  updateOrderStatus,
  updatePaymentStatus,
} = require("../../controllers/admin/orderController");

const router = express.Router();

// All routes require admin authentication
router.use(authenticate);
router.use(requireAdmin);

router.get("/", getAllOrders);
router.put("/:orderId/status", updateOrderStatus);
router.put("/:orderId/payment", updatePaymentStatus);

module.exports = router;