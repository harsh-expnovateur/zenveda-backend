// controllers/admin/orderController.js
const {
  getAllOrders: getAllOrdersModel,
  getOrderById,
  updateOrderStatus: updateOrderStatusModel,
} = require("../../models/admin/orderModel");
const logger = require("../../config/logger");
const { sendEmail } = require("../../utils/mailer");
const {
  orderShippedTemplate,
  orderDeliveredTemplate,
  orderCancelledTemplate,
} = require("../../utils/emailTemplates");

/**
 * Get all orders for admin
 */
const getAllOrders = async (req, res) => {
  try {
    const orders = await getAllOrdersModel();

    res.json({
      success: true,
      orders,
    });
  } catch (err) {
    logger.error("Get all orders error", { message: err.message, stack: err.stack });
    res.status(500).json({
      success: false,
      error: "Failed to fetch orders",
    });
  }
};

/**
 * Update order status
 */
const updateOrderStatus = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { status } = req.body;

    const validStatuses = ["Pending", "Shipped", "Delivered", "Cancelled"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: "Invalid status",
      });
    }

    // Get order details before updating
    const orderDetails = await getOrderById(parseInt(orderId));
    if (!orderDetails) {
      return res.status(404).json({
        success: false,
        error: "Order not found",
      });
    }

    // Update status
    await updateOrderStatusModel(parseInt(orderId), status, null);

    // Send email notification based on status (non-blocking)
    sendStatusEmail(orderDetails, status).catch((err) => {
      logger.error("Failed to send status email", { orderId, status, error: err.message });
    });

    logger.info("Order status updated", {
      orderId,
      status,
      adminId: req.user.id,
    });

    res.json({
      success: true,
      message: "Order status updated successfully",
    });
  } catch (err) {
    logger.error("Update order status error", { message: err.message, stack: err.stack });
    res.status(500).json({
      success: false,
      error: "Failed to update order status",
    });
  }
};

/**
 * Update payment status
 */
const updatePaymentStatus = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { payment_status } = req.body;

    const validPaymentStatuses = ["unpaid", "paid"];
    if (!validPaymentStatuses.includes(payment_status)) {
      return res.status(400).json({
        success: false,
        error: "Invalid payment status",
      });
    }

    await updateOrderStatusModel(parseInt(orderId), null, payment_status);

    logger.info("Order payment status updated", {
      orderId,
      payment_status,
      adminId: req.user.id,
    });

    res.json({
      success: true,
      message: "Payment status updated successfully",
    });
  } catch (err) {
    logger.error("Update payment status error", { message: err.message, stack: err.stack });
    res.status(500).json({
      success: false,
      error: "Failed to update payment status",
    });
  }
};

/**
 * Send email based on status change (async)
 */
async function sendStatusEmail(orderDetails, status) {
  const { order, items } = orderDetails;
  
  let subject = "";
  let template = null;

  const emailData = {
    customerName: order.customer_name,
    orderNumber: order.order_number,
    totalAmount: parseFloat(order.total_amount).toFixed(2),
    items: items,
    shippingAddress: {
      address: order.shipping_address,
      city: order.shipping_city,
      state: order.shipping_state,
      pincode: order.shipping_pincode,
    },
  };

  switch (status) {
    case "Shipped":
      subject = `Order Shipped - ${order.order_number}`;
      template = orderShippedTemplate(emailData);
      break;
    case "Delivered":
      subject = `Order Delivered - ${order.order_number}`;
      template = orderDeliveredTemplate(emailData);
      break;
    case "Cancelled":
      subject = `Order Cancelled - ${order.order_number}`;
      template = orderCancelledTemplate(emailData);
      break;
    default:
      return; // Don't send email for Pending status
  }

  if (template) {
    await sendEmail({
      to: order.customer_email,
      subject: subject,
      html: template,
    });
  }
}

module.exports = {
  getAllOrders,
  updateOrderStatus,
  updatePaymentStatus,
};