// controllers/customer/orderController.js
const {
  createOrder,
  addOrderItems,
  getCustomerOrders,
  getOrderDetails,
} = require("../../models/customer/orderModel");
const { getCartItems, clearCart } = require("../../models/customer/cartModel");
const logger = require("../../config/logger");

// === ADDED: Import mailer and templates ===
const { sendEmail } = require("../../utils/mailer");
const {
  customerTemplate,
  adminTemplate,
} = require("../../utils/emailTemplates");

/**
 * Create order from cart
 */
const placeOrder = async (req, res) => {
  try {
    const customerId = req.user.id;
    const {
      shippingAddress,
      shippingCity,
      shippingState,
      shippingPincode,
      customerName,
      customerPhone,
      customerEmail,
    } = req.body;

    // Validation
    if (
      !shippingAddress ||
      !shippingCity ||
      !shippingState ||
      !shippingPincode ||
      !customerName ||
      !customerPhone
    ) {
      return res.status(400).json({
        success: false,
        error: "All shipping details are required",
      });
    }

    // Get cart items
    const cartItems = await getCartItems(customerId);
    if (cartItems.length === 0) {
      return res.status(400).json({
        success: false,
        error: "Cart is empty",
      });
    }

    // Calculate total
    const totalAmount = cartItems.reduce(
      (sum, item) => sum + parseFloat(item.selling_price) * item.quantity,
      0
    );

    // Create order
    const order = await createOrder({
      customerId,
      totalAmount,
      shippingAddress,
      shippingCity,
      shippingState,
      shippingPincode,
      customerName,
      customerPhone,
      customerEmail: customerEmail || req.user.email,
    });

    // Add order items
    const orderItems = cartItems.map((item) => ({
      tea_id: item.tea_id,
      package_id: item.package_id,
      tea_name: item.tea_name,
      package_name: item.package_name,
      quantity: item.quantity,
      price_per_unit: parseFloat(item.selling_price),
      subtotal: parseFloat(item.selling_price) * item.quantity,
    }));

    await addOrderItems(order.order_id, orderItems);

    // Clear cart
    await clearCart(customerId);

    // === ADDED: Prepare order data for email ===
    // In placeOrder function, update email data preparation:
    const orderDataForEmail = {
      customerName: customerName,
      orderNumber: order.order_number,
      totalAmount: totalAmount.toFixed(2),
      customerEmail: customerEmail || req.user.email,
      items: orderItems,
      shippingAddress: {
        address: shippingAddress,
        city: shippingCity,
        state: shippingState,
        pincode: shippingPincode,
      },
    };

    // Update email sending to be non-blocking
    sendEmail({
      to: orderDataForEmail.customerEmail,
      subject: `Order Confirmation - ${orderDataForEmail.orderNumber}`,
      html: customerTemplate(orderDataForEmail),
    }).catch((err) => {
      logger.error("Failed to send customer email", { error: err.message });
    });

    sendEmail({
      to: process.env.ADMIN_EMAIL || "admin@yourstore.com",
      subject: `New Order Received - ${orderDataForEmail.orderNumber}`,
      html: adminTemplate(orderDataForEmail),
    }).catch((err) => {
      logger.error("Failed to send admin email", { error: err.message });
    });

    logger.info("Order placed successfully", {
      customerId,
      orderId: order.order_id,
      orderNumber: order.order_number,
    });

    res.status(201).json({
      success: true,
      message: "Order placed successfully",
      order: {
        orderId: order.order_id,
        orderNumber: order.order_number,
        totalAmount,
      },
    });
  } catch (err) {
    logger.error("Place order error", {
      message: err.message,
      stack: err.stack,
    });
    res.status(500).json({
      success: false,
      error: "Failed to place order",
    });
  }
};

/**
 * Get customer orders
 */
const getOrders = async (req, res) => {
  try {
    const customerId = req.user.id;
    const orders = await getCustomerOrders(customerId);

    res.json({
      success: true,
      orders,
    });
  } catch (err) {
    logger.error("Get orders error", {
      message: err.message,
      stack: err.stack,
    });
    res.status(500).json({
      success: false,
      error: "Failed to fetch orders",
    });
  }
};

/**
 * Get order details
 */
const getOrder = async (req, res) => {
  try {
    const customerId = req.user.id;
    const { orderId } = req.params;

    const orderData = await getOrderDetails(parseInt(orderId), customerId);
    if (!orderData) {
      return res.status(404).json({
        success: false,
        error: "Order not found",
      });
    }

    res.json({
      success: true,
      order: orderData,
    });
  } catch (err) {
    logger.error("Get order details error", {
      message: err.message,
      stack: err.stack,
    });
    res.status(500).json({
      success: false,
      error: "Failed to fetch order details",
    });
  }
};

module.exports = {
  placeOrder,
  getOrders,
  getOrder,
};
