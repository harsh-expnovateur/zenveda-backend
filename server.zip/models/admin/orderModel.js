// models/admin/orderModel.js
const { getPool, mssql } = require("../../config/db");

/**
 * Get all orders (admin view)
 */
async function getAllOrders() {
  const pool = await getPool();
  const result = await pool.query(`
    SELECT 
      order_id,
      customer_id,
      order_number,
      total_amount,
      status,
      payment_status,
      order_date,
      shipping_address,
      shipping_city,
      shipping_state,
      shipping_pincode,
      customer_name,
      customer_phone,
      customer_email,
      created_at,
      updated_at
    FROM orders
    ORDER BY order_date DESC
  `);
  return result.recordset;
}

/**
 * Get order by ID with items
 */
async function getOrderById(orderId) {
  const pool = await getPool();

  const orderResult = await pool
    .request()
    .input("order_id", mssql.Int, orderId)
    .query(`
      SELECT *
      FROM orders
      WHERE order_id = @order_id
    `);

  if (orderResult.recordset.length === 0) return null;

  const itemsResult = await pool
    .request()
    .input("order_id", mssql.Int, orderId)
    .query(`
      SELECT *
      FROM order_items
      WHERE order_id = @order_id
    `);

  return {
    order: orderResult.recordset[0],
    items: itemsResult.recordset,
  };
}

/**
 * Update order status and/or payment status
 */
async function updateOrderStatus(orderId, status = null, paymentStatus = null) {
  const pool = await getPool();
  
  let query = "UPDATE orders SET updated_at = SYSUTCDATETIME()";
  const params = [];
  
  if (status !== null) {
    query += ", status = @status";
    params.push({ name: "status", type: mssql.NVarChar(50), value: status });
  }
  
  if (paymentStatus !== null) {
    query += ", payment_status = @payment_status";
    params.push({ name: "payment_status", type: mssql.NVarChar(50), value: paymentStatus });
  }
  
  query += " WHERE order_id = @order_id";
  
  const request = pool.request().input("order_id", mssql.Int, orderId);
  
  params.forEach(param => {
    request.input(param.name, param.type, param.value);
  });
  
  await request.query(query);
}

module.exports = {
  getAllOrders,
  getOrderById,
  updateOrderStatus,
};