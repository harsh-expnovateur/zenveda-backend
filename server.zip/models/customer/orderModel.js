// models/customer/orderModel.js
const { getPool, mssql } = require("../../config/db");

/**
 * Generate a unique order number
 */
function generateOrderNumber() {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 7).toUpperCase();
  return `ORD-${timestamp}-${random}`;
}

/**
 * Create a new order record
 */
async function createOrder({
  customerId,
  totalAmount,
  shippingAddress,
  shippingCity,
  shippingState,
  shippingPincode,
  customerName,
  customerPhone,
  customerEmail,
}) {
  const pool = await getPool();
  const orderNumber = generateOrderNumber();

  const result = await pool
    .request()
    .input("customer_id", mssql.Int, customerId)
    .input("order_number", mssql.NVarChar(50), orderNumber)
    .input("total_amount", mssql.Decimal(10, 2), totalAmount)
    .input("shipping_address", mssql.NVarChar(500), shippingAddress)
    .input("shipping_city", mssql.NVarChar(100), shippingCity)
    .input("shipping_state", mssql.NVarChar(100), shippingState)
    .input("shipping_pincode", mssql.NVarChar(10), shippingPincode)
    .input("customer_name", mssql.NVarChar(100), customerName)
    .input("customer_phone", mssql.NVarChar(15), customerPhone)
    .input("customer_email", mssql.NVarChar(150), customerEmail)
    .query(`
      INSERT INTO orders (
        customer_id, order_number, total_amount,
        shipping_address, shipping_city, shipping_state, shipping_pincode,
        customer_name, customer_phone, customer_email
      )
      OUTPUT INSERTED.order_id, INSERTED.order_number
      VALUES (
        @customer_id, @order_number, @total_amount,
        @shipping_address, @shipping_city, @shipping_state, @shipping_pincode,
        @customer_name, @customer_phone, @customer_email
      )
    `);

  return result.recordset[0];
}

/**
 * Add multiple order items to a given order
 */
async function addOrderItems(orderId, items) {
  const pool = await getPool();

  for (const item of items) {
    await pool
      .request()
      .input("order_id", mssql.Int, orderId)
      .input("tea_id", mssql.Int, item.tea_id)
      .input("package_id", mssql.Int, item.package_id)
      .input("tea_name", mssql.NVarChar(200), item.tea_name)
      .input("package_name", mssql.NVarChar(50), item.package_name)
      .input("quantity", mssql.Int, item.quantity)
      .input("price_per_unit", mssql.Decimal(10, 2), item.price_per_unit)
      .input("subtotal", mssql.Decimal(10, 2), item.subtotal)
      .query(`
        INSERT INTO order_items (
          order_id, tea_id, package_id, tea_name, package_name,
          quantity, price_per_unit, subtotal
        )
        VALUES (
          @order_id, @tea_id, @package_id, @tea_name, @package_name,
          @quantity, @price_per_unit, @subtotal
        )
      `);
  }
}

/**
 * Get all orders for a customer
 */
async function getCustomerOrders(customerId) {
  const pool = await getPool();
  const result = await pool
    .request()
    .input("customer_id", mssql.Int, customerId)
    .query(`
      SELECT 
        order_id, order_number, total_amount, status, payment_status,
        order_date, created_at, updated_at
      FROM orders
      WHERE customer_id = @customer_id
      ORDER BY order_date DESC
    `);
  return result.recordset;
}

/**
 * Get order details with items for a specific order
 */
async function getOrderDetails(orderId, customerId) {
  const pool = await getPool();

  // Get order details
  const orderResult = await pool
    .request()
    .input("order_id", mssql.Int, orderId)
    .input("customer_id", mssql.Int, customerId)
    .query(`
      SELECT *
      FROM orders
      WHERE order_id = @order_id AND customer_id = @customer_id
    `);

  if (orderResult.recordset.length === 0) return null;

  // Get related items
  const itemsResult = await pool
    .request()
    .input("order_id", mssql.Int, orderId)
    .query(`
      SELECT *
      FROM order_items
      WHERE order_id = @order_id
    `);

  return {
    order: orderResult.recordset[0],
    items: itemsResult.recordset,
  };
}

/**
 * Update order status or payment info
 */
async function updateOrderStatus(orderId, status, paymentStatus = null) {
  const pool = await getPool();
  const query = `
    UPDATE orders
    SET status = @status,
        payment_status = ISNULL(@payment_status, payment_status),
        updated_at = SYSUTCDATETIME()
    WHERE order_id = @order_id
  `;
  await pool
    .request()
    .input("order_id", mssql.Int, orderId)
    .input("status", mssql.NVarChar(50), status)
    .input("payment_status", mssql.NVarChar(50), paymentStatus)
    .query(query);
}

module.exports = {
  createOrder,
  addOrderItems,
  getCustomerOrders,
  getOrderDetails,
  updateOrderStatus,
};
